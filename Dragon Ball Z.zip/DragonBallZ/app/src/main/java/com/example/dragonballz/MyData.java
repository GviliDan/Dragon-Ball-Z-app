package com.example.dragonballz;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MyData {

    static String[] nameArray = {"Songoku", "Bulma", "Kririn", "Piccolo", "Gohan", "Vegeta",
            "Trunks","Bardock", "Master_Roshi", "Yamcha", "Tien_shinhan"};
    static String[] versionArray = {"Main characters","Main characters","Main characters","Main characters",
            "Main characters","Main characters","Main characters","Secondary characters",
            "Secondary characters","Secondary characters","Secondary characters"};

    static Integer[] drawableArray = {R.drawable.songoku, R.drawable.bulma, R.drawable.kririn,
            R.drawable.piccolo, R.drawable.gohan, R.drawable.vegeta, R.drawable.trunks,
            R.drawable.bardock, R.drawable.master_roshi, R.drawable.yamcha,R.drawable.tien_shinhan};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    static String[] HeroDeatails= {"First introduced as a young boy, Son Goku (孫悟空, Son Gokū) is depicted as immensely strong, pure of heart, and extremely competitive, but dedicated to defending his adopted home Earth from internal or external threats. Although he appears human, it is later revealed that Goku is a Saiyan, and that his original name is Kakarrot."
            ,"Bulma (ブルマ, Buruma) first appears as a teenager using the Dragon Radar, a fictional device she created to detect the energy signal emitted by Dragon Balls. She is led to Goku's location by the signal emitted by the four-star ball in his possession and recruits him as a bodyguard while hoping to get his four-star ball to grant her wish for a boyfriend.",
            "Krillin (クリリン, Kuririn) is a bald martial artist and one of Goku's best friends and classmates. He and Goku are under the tutelage of Master Roshi;[ch. 28] initially his rival but later a friend, and a loyal companion in adventures thereafter. He is killed by King Piccolo's spawn Tambourine, but is later revived by Shenron.[ch. 135, 165] After the fight with the Saiyans, he travels to Planet Namek, where he is killed by Frieza."
            ,"Piccolo (ピッコロ, Pikkoro) is the spawn of King Piccolo, created to get revenge on Goku in the wake of his death, and subsequently assumes the role as the evil half of Kami ",
            "Son Gohan (孫悟飯) is Goku's eldest son with Chi-Chi, who first appears at the age of four.[ch. 196] He is kidnapped by Goku's brother, Raditz, and locked up in a space pod. However, his temper flares and he bursts out of the space pod, dealing a blow to Raditz and knocking himself out. ",
            "Vegeta (ベジータ, Bejīta) is the last prince of the Saiyan warrior people, and the fourth generation of the Saiyan royal bloodline to bear his namesake. He is first shown conquering a planet with his partner Nappa by listening to Raditz's fight on Earth using their scouters.",
            "Trunks (トランクス, Torankusu) first appears as a mysterious young man who easily defeats Frieza and his father King Cold prior to Goku's return to Earth from Planet Namek.[ch. 331, 332] It is revealed that he is Vegeta and Bulma's future child who has traveled back in time to inform Goku of the arrival of the Red Ribbon Androids that, in his time, have killed everyone else in the Dragon Team besides Goku, who died of heart disease.",
            "Bardock (バーダック, Bādakku)—or Burdock in Viz's English manga translation—is the husband of Gine (ギネ), and the father of Raditz and Kakarrot (Goku).",
            "Kame-Sen'nin (亀仙人, Turtle Hermit), also known as Muten-Rōshi (武天老師, lit Martial Arts Genius Master), which is rendered as Master Roshi in the English versions, is a lecherous elderly martial arts master instructor that lives on a small island and is the inventor of the Kamehameha technique. ",
            "Yamcha (ヤムチャ, Yamucha), known as Zedaki in the Harmony Gold dub, is introduced as a desert bandit alongside his companion Puar, trying to steal Goku and Bulma's Dragon Balls. He becomes nervous when near women.[ch. 8, 9] He eventually becomes Goku's ally, starts a relationship with Bulma, and later becomes a pupil of Master Roshi.",
            "Tenshinhan (天津飯テンシンハン), named Tien Shinhan in the Funimation anime dub and also known as Shinto in the Harmony Gold dub, is first introduced, having been trained by Master Roshi's rival Master Shen, trying to kill Goku and his fellow-students.[ch. 113, 129] Later, he and Chiaotzu become their allies, fighting against King Piccolo's minion until Goku arrives.[ch. 147, 154] In the fight with the Saiyans, Tien Shinhan dies of exhaustion against Nappa."};

    public static void  getPicture(View view, int id) {
        ImageView imageView= view.findViewById(R.id.imageView2);
        imageView.setImageResource(drawableArray[id]);
    }

    public static void  getMoreDetails(View view, int id) {
        TextView textView = view.findViewById(R.id.textView3);
        textView.setText(HeroDeatails[id]);
    }
}
